# FuzzPyCrunch

Supported File Formats
=========================================================
CSV, XML, JSON, JPEG, ELF, PDF
