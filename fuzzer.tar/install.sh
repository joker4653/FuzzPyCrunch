#!/bin/bash

sudo apt update
sudo apt install software-properties-common
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt-get install tmux
sudo apt update
sudo apt-get install build-essential
sudo apt-get install python3-pip
pip install Pillow
pip3 install Pillow
