import random

class mutateELF:
    def validateInput():
        pass