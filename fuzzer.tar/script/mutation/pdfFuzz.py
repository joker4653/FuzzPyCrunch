import random



class mutatePDF:
    def validateInput():
        pass